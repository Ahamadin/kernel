/* This file is auto generated, version 202101061537 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#202101061537 SMP Wed Jan 6 15:43:53 UTC 2021"
#define LINUX_COMPILE_BY "kernel"
#define LINUX_COMPILE_HOST "gloin"
#define LINUX_COMPILER "gcc (Ubuntu 10.2.0-13ubuntu1) 10.2.0, GNU ld (GNU Binutils for Ubuntu) 2.35.1"
